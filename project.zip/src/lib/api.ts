import axios from 'axios'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL ?? 'http://localhost:4000/api',
  withCredentials: true, // sends/receives the httpOnly refresh-token cookie
})

// Access token is held in memory only (never localStorage) — a module-level
// variable is enough since AuthContext is the only thing that sets it.
let accessToken: string | null = null
let refreshPromise: Promise<string> | null = null

export function setAccessToken(token: string | null) {
  accessToken = token
}

api.interceptors.request.use((config) => {
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`
  }
  return config
})

// If a request 401s (expired access token), try one silent refresh, then
// retry the original request once.
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config

    // Never try to "refresh" a failed auth call itself — that's what causes loops.
    const isAuthEndpoint =
      original?.url?.includes('/auth/refresh-token') ||
      original?.url?.includes('/auth/login') ||
      original?.url?.includes('/auth/register')

    if (error.response?.status === 401 && !original._retry && !isAuthEndpoint) {
      original._retry = true
      try {
        if (!refreshPromise) {
          refreshPromise = api
            .post('/auth/refresh-token')
            .then(({ data }) => data.data.accessToken as string)
            .finally(() => { refreshPromise = null })
        }
        const token = await refreshPromise
        setAccessToken(token)
        original.headers = original.headers ?? {}
        original.headers.Authorization = `Bearer ${token}`
        return api(original)
      } catch {
        setAccessToken(null)
      }
    }
    return Promise.reject(error)
  }
)
