import { userRepository } from '../repositories/user.repository'
import { planRepository } from '../repositories/plan.repository'
import { nextcloudService, NextcloudApiError } from './NextcloudService'
import { encrypt } from '../utils/encryption'
import { hashPassword } from '../utils/password'
import { ApiError } from '../utils/ApiError'
import { DEFAULT_PLAN_NAME } from '../config/plans'
import { logger } from '../config/logger'
import { UserWithPlan } from '../models/user.model'

export interface ProvisionUserInput {
  name: string
  email: string
  password: string
  phoneNumber?: string
  emailVerifiedAt?: Date | null
  // Omitted → resolves to the seeded default plan, exactly like a normal
  // self-registration always has. Only admin-initiated creation (Phase 10)
  // ever passes this explicitly.
  planId?: string
  // Omitted → 'USER', same default the `role` column itself has. Only
  // admin-initiated creation can produce another ADMIN account this way —
  // self-registration never passes this.
  role?: 'USER' | 'ADMIN'
  // Self-registration passes this so the acceptance row is written in the
  // same nested create as the user — either both exist or neither does.
  // Admin-created accounts and the seed admin leave it out.
  agreementAcceptance?: {
    version: string
    ipAddress?: string
    userAgent?: string
  }
}

/**
 * The full account-creation pipeline: validates the email is free, resolves
 * a plan, creates the Postgres row, provisions the matching Nextcloud
 * account (quota-limited to the plan), and rolls the Postgres row back if
 * Nextcloud provisioning fails — so there's never a Postgres user left
 * behind with no storage backend, regardless of which caller triggered
 * this.
 *
 * Used by both auth.service.ts's register() (self-signup, always role
 * USER, always the default plan) and admin.service.ts's createUser()
 * (Phase 10 — an admin may pick a specific plan and/or role). Keeping this
 * one path shared means a future change to the provisioning sequence only
 * has to happen once.
 */
export async function provisionUser(input: ProvisionUserInput): Promise<UserWithPlan> {
  const existing = await userRepository.findByEmail(input.email)
  if (existing) {
    throw ApiError.conflict('An account with this email already exists')
  }

  const plan = input.planId
    ? await planRepository.findById(input.planId)
    : await planRepository.findByName(DEFAULT_PLAN_NAME)

  if (!plan) {
    if (input.planId) {
      // Caller-supplied id that doesn't exist — a bad request, not a
      // server misconfiguration.
      throw ApiError.badRequest('Invalid plan')
    }
    // Fails loudly rather than silently creating a plan-less account —
    // almost always means `npm run prisma:seed` hasn't been run yet.
    throw ApiError.internal(
      `Default plan "${DEFAULT_PLAN_NAME}" not found. Run "npm run prisma:seed" to seed plans.`
    )
  }

  const passwordHash = await hashPassword(input.password)

  // 1. Create the PostgreSQL user first — it's the source of truth for
  // "does this account exist", and gives us a stable, unique id to use
  // as the Nextcloud username (sidesteps Nextcloud's username character
  // restrictions entirely — a UUID is always valid).
  const user = await userRepository.create({
    name: input.name,
    email: input.email,
    phoneNumber: input.phoneNumber,
    emailVerifiedAt: input.emailVerifiedAt,
    passwordHash,
    role: input.role ?? 'USER',
    plan: { connect: { id: plan.id } },
    ...(input.agreementAcceptance
      ? {
          agreementAcceptances: {
            create: {
              agreementVersion: input.agreementAcceptance.version,
              email: input.email,
              event: 'REGISTRATION',
              ipAddress: input.agreementAcceptance.ipAddress,
              userAgent: input.agreementAcceptance.userAgent,
            },
          },
        }
      : {}),
  })

  // 2. Provision the matching Nextcloud account, quota-limited to the
  // resolved plan. If this fails, roll back the Postgres user rather than
  // leaving an account with no storage backend behind it.
  const nextcloudUsername = user.id
  let webdavPassword: string
  try {
    const result = await nextcloudService.createUser(
      nextcloudUsername,
      input.password,
      plan.storageLimit,
      input.name,
      input.email
    )
    webdavPassword = result.webdavPassword
  } catch (err) {
    await userRepository.delete(user.id)
    const detail = err instanceof NextcloudApiError ? err.message : 'unknown error'
    logger.error({ userId: user.id, detail }, 'Nextcloud provisioning failed — rolled back Postgres user')
    if (err instanceof NextcloudApiError && err.code === 'PASSWORD_TOO_WEAK') {
      throw ApiError.badRequest(
        'Password is too weak. Please use a stronger password with a mix of letters, numbers, and symbols.'
      )
    }
    throw ApiError.serviceUnavailable('Could not set up the storage account. Please try again.')
  }

  // 3. Store the Nextcloud username and encrypted WebDAV credential. If the
  // Postgres write fails after the external account exists, compensate by
  // deleting the Nextcloud account so a retry is not blocked by an orphan.
  try {
    return await userRepository.update(user.id, {
      nextcloudUsername,
      nextcloudWebdavPasswordEncrypted: encrypt(webdavPassword),
    })
  } catch (err) {
    try {
      await nextcloudService.deleteUser(nextcloudUsername)
    } catch (cleanupErr) {
      logger.error({ userId: user.id, cleanupErr }, 'Failed to clean up Nextcloud account after Postgres provisioning failure')
    }
    await userRepository.delete(user.id).catch((deleteErr) => {
      logger.error({ userId: user.id, deleteErr }, 'Failed to roll back Postgres user after provisioning failure')
    })
    throw ApiError.serviceUnavailable('Could not finish setting up the account. Please try again.')
  }
}
