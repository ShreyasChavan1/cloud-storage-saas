export class ApiError extends Error {
  public readonly statusCode: number
  public readonly isOperational: boolean
  public readonly details?: unknown

  constructor(statusCode: number, message: string, details?: unknown, isOperational = true) {
    super(message)
    this.statusCode = statusCode
    this.isOperational = isOperational
    this.details = details
    Object.setPrototypeOf(this, ApiError.prototype)
    Error.captureStackTrace(this, this.constructor)
  }

  static badRequest(message = 'Bad request', details?: unknown) {
    return new ApiError(400, message, details)
  }

  static unauthorized(message = 'Unauthorized') {
    return new ApiError(401, message)
  }

  static forbidden(message = 'Forbidden') {
    return new ApiError(403, message)
  }

  static notFound(message = 'Not found') {
    return new ApiError(404, message)
  }

  static conflict(message = 'Conflict') {
    return new ApiError(409, message)
  }

  static internal(message = 'Internal server error') {
    return new ApiError(500, message, undefined, false)
  }

  static serviceUnavailable(message = 'Service temporarily unavailable') {
    return new ApiError(503, message)
  }

  static insufficientStorage(message = 'Storage quota exceeded') {
    return new ApiError(507, message)
  }
}
