import { z } from 'zod'

const nameField = z
  .string()
  .min(1, 'Name is required')
  .max(255)
  .regex(/^[^/\0]+$/, 'Name cannot contain a path separator')

export const listFilesSchema = z.object({
  query: z.object({
    path: z.string().optional(),
  }),
})

export const uploadFileSchema = z.object({
  query: z.object({
    path: z.string().optional(),
  }),
})

export const deleteFileSchema = z.object({
  query: z.object({
    path: z.string().min(1, 'path is required'),
  }),
})

export const trashItemSchema = z.object({
  params: z.object({
    id: z.string().min(1, 'id is required'),
  }),
})

export const renameFileSchema = z.object({
  body: z.object({
    path: z.string().min(1, 'path is required'),
    newName: nameField,
  }),
})

export const createFolderSchema = z.object({
  body: z.object({
    path: z.string().optional(),
    name: nameField,
  }),
})

export const moveFileSchema = z.object({
  body: z.object({
    from: z.string().min(1, 'from is required'),
    to: z.string().min(1, 'to is required'),
  }),
})

export const copyFileSchema = z.object({
  body: z.object({
    from: z.string().min(1, 'from is required'),
    to: z.string().min(1, 'to is required'),
  }),
})

export const downloadFileSchema = z.object({
  query: z.object({
    path: z.string().min(1, 'path is required'),
  }),
})

export type RenameFileInput = z.infer<typeof renameFileSchema>['body']
export type CreateFolderInput = z.infer<typeof createFolderSchema>['body']
export type MoveFileInput = z.infer<typeof moveFileSchema>['body']
export type CopyFileInput = z.infer<typeof copyFileSchema>['body']

export const favoriteFileSchema = z.object({
  body: z.object({
    path: z.string().min(1, 'path is required'),
    favorite: z.boolean(),
  }),
})
export const versionsSchema=z.object({query:z.object({path:z.string().min(1)})})
export const restoreVersionSchema=z.object({body:z.object({path:z.string().min(1),revision:z.string().regex(/^\d+$/)})})

// ---- Chunked uploads ----------------------------------------------------
const MAX_UPLOAD_BYTES = 10 * 1024 * 1024 * 1024
const uploadIdField = z.string().regex(/^[0-9a-fA-F-]{36}$/, 'Invalid upload id')
const uploadSizeField = z.number().int().positive().max(MAX_UPLOAD_BYTES, 'File is too large')

export const startChunkedUploadSchema = z.object({
  body: z.object({
    path: z.string().optional(),
    filename: nameField,
    size: uploadSizeField,
  }),
})

export const uploadChunkSchema = z.object({
  params: z.object({
    uploadId: uploadIdField,
    index: z.coerce.number().int().min(1).max(10000),
  }),
  query: z.object({
    path: z.string().optional(),
    filename: nameField,
    size: z.coerce.number().int().positive().max(MAX_UPLOAD_BYTES),
  }),
})

export const completeChunkedUploadSchema = z.object({
  params: z.object({ uploadId: uploadIdField }),
  body: z.object({
    path: z.string().optional(),
    filename: nameField,
    size: uploadSizeField,
  }),
})

export const abortChunkedUploadSchema = z.object({
  params: z.object({ uploadId: uploadIdField }),
})
