import { Request, Response } from 'express'
import ms from 'ms'
import { authService } from '../services/auth.service'
import { asyncHandler } from '../utils/asyncHandler'
import { sendSuccess } from '../utils/response'
import { ApiError } from '../utils/ApiError'
import { env } from '../config/env'

const REFRESH_COOKIE_NAME = 'nimbus_refresh_token'

// Refresh token lives in an httpOnly cookie so it's never touchable from
// JS (mitigates XSS token theft); the access token goes in the JSON body
// for the client to hold in memory and attach as a Bearer header.
function setRefreshCookie(res: Response, token: string) {
  res.cookie(REFRESH_COOKIE_NAME, token, {
    httpOnly: true,
    secure: env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: ms(env.JWT_REFRESH_EXPIRES_IN),
    path: '/api/auth',
  })
}

function clearRefreshCookie(res: Response) {
  res.clearCookie(REFRESH_COOKIE_NAME, { path: '/api/auth' })
}

// Read once per request rather than inline at each call site below — both
// register/login/refresh want the same two values for the session row
// Phase 10's admin "active sessions" view reads (see auth.service.ts's
// SessionMeta). `req.ip` respects Express's `trust proxy` setting if one
// is ever configured; today it's just the raw socket address.
function sessionMetaFrom(req: Request) {
  return { userAgent: req.headers['user-agent'], ipAddress: req.ip }
}

export const authController = {
  register: asyncHandler(async (req: Request, res: Response) => {
    const { refreshToken, ...result } = await authService.register(req.body, sessionMetaFrom(req))
    setRefreshCookie(res, refreshToken)
    return sendSuccess(res, result, 201)
  }),

  login: asyncHandler(async (req: Request, res: Response) => {
    const { refreshToken, ...result } = await authService.login(req.body, sessionMetaFrom(req))
    setRefreshCookie(res, refreshToken)
    return sendSuccess(res, result, 200)
  }),

  refresh: asyncHandler(async (req: Request, res: Response) => {
    const token = req.cookies?.[REFRESH_COOKIE_NAME]
    if (!token) throw ApiError.unauthorized('No refresh token provided')

    const { refreshToken, ...result } = await authService.refresh(token, sessionMetaFrom(req))
    setRefreshCookie(res, refreshToken)
    return sendSuccess(res, result, 200)
  }),

  forgotPassword: asyncHandler(async (req: Request, res: Response) => {
    const { devToken } = await authService.forgotPassword(req.body)

    // Same response whether or not the email is registered — never reveal
    // which one it was.
    return sendSuccess(res, {
      message: 'If an account exists for that email, a reset link has been sent.',
      // Only present outside production, and only while no mailer exists.
      ...(devToken ? { devToken } : {}),
    })
  }),

  logout: asyncHandler(async (req: Request, res: Response) => {
    const token = req.cookies?.[REFRESH_COOKIE_NAME]
    await authService.logout(token)
    clearRefreshCookie(res)
    return sendSuccess(res, { loggedOut: true })
  }),

  me: asyncHandler(async (req: Request, res: Response) => {
    const user = await authService.me(req.user!.sub)
    return sendSuccess(res, { user })
  }),
}
