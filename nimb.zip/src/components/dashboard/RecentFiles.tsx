import { Link } from 'react-router-dom'
import { AlertCircle, FileText } from 'lucide-react'
import { Card } from '@/components/ui/Card'
import { useStorageStats } from '@/hooks/useStorageStats'
import { fileKindMeta, kindFromName } from '@/lib/fileIcons'
import { formatBytes } from '@/lib/formatBytes'
import { dirname } from '@/lib/paths'
import { FileMenu } from '@/components/files/FileMenu'

// Backed by the account-wide /files/stats scan (not just the root folder)
// — files uploaded anywhere in the tree show up here, sorted by modified
// date, already limited to the 10 most recent by the backend.
export function RecentFiles() {
  const { data: stats, isLoading, isError } = useStorageStats()
  const recent = (stats?.recentUploads ?? []).slice(0, 5)

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-semibold">Recent uploads</h3>
        <Link to="/files" className="text-sm font-medium text-brand-600 hover:text-brand-700 dark:text-brand-400">
          View all
        </Link>
      </div>

      {isLoading ? (
        <div className="mt-3 flex flex-col gap-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-12 animate-pulse rounded-xl bg-surface-100 dark:bg-dark-surface2" />
          ))}
        </div>
      ) : isError ? (
        <div className="mt-6 flex flex-col items-center text-center text-sm text-danger">
          <AlertCircle className="mb-2 h-6 w-6" />
          Couldn't load recent uploads.
        </div>
      ) : recent.length === 0 ? (
        <div className="mt-6 flex flex-col items-center text-center text-sm text-ink-400">
          <FileText className="mb-2 h-6 w-6 text-ink-300" />
          No files yet — upload something to see it here.
        </div>
      ) : (
        <div className="mt-3 flex flex-col divide-y divide-line dark:divide-dark-border">
          {recent.map((file) => {
            const meta = fileKindMeta[kindFromName(file.name)]
            const Icon = meta.icon
            return (
              <div key={file.path} className="group flex items-center gap-3 py-3 first:pt-0 last:pb-0">
                <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${meta.bg}`}>
                  <Icon className={`h-[18px] w-[18px] ${meta.fg}`} strokeWidth={1.75} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-ink-900 dark:text-white" title={file.path}>
                    {file.name}
                  </p>
                  <p className="text-xs text-ink-400">
                    {formatBytes(file.size)} · {new Date(file.modifiedAt).toLocaleDateString()}
                  </p>
                </div>
                <div className="opacity-0 transition-opacity group-hover:opacity-100">
                  {/* This file could be anywhere in the tree now (not just
                      root) — invalidate its own parent folder, not root,
                      so a rename/move/delete from here is reflected if the
                      person later browses into that actual folder. */}
                  <FileMenu entry={file} currentPath={dirname(file.path)} />
                </div>
              </div>
            )
          })}
        </div>
      )}
    </Card>
  )
}
